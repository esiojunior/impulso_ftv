# Impulso — Futevôlei

Aplicativo **offline** para Android, em português, baseado no arquivo “Treino para futevolei.pdf” do usuário e adaptado ao cronograma:

- Segunda: futevôlei.
- Terça: Treino A — força de membros inferiores.
- Quarta: futevôlei.
- Quinta: superiores + mobilidade (complementar).
- Sexta: Treino B — pliometria/potência/complexo, com volume reduzido antes do jogo.
- Sábado: futevôlei.
- Domingo: descanso.

## Uso imediato no celular (sem compilar)

O arquivo `Impulso_Futevolei.html` (disponibilizado separadamente junto deste projeto) abre em navegador moderno Android. Os dados são salvos no armazenamento local da página; **mantenha o arquivo no mesmo local** e faça backups JSON regularmente. Essa é uma versão web offline, não um APK nem instalação nativa. Para obter o ícone de aplicativo na tela inicial por meio do navegador, hospede a pasta `app/src/main/assets/` em HTTPS e use "Instalar aplicativo/Adicionar à tela inicial" no Chrome Android (PWA).

## Gerar APK Android (Android Studio)

O código-fonte fornecido contém um projeto Gradle para Android Studio, mas **não contém APK pré-compilado**. A plataforma de compilação Android não está presente no ambiente em que o projeto foi preparado.

1. Abra o **Android Studio** atualizado (com JDK 17 e Android SDK Platform 35).
2. Abra a pasta `Impulso_Futevolei` como projeto.
3. Este projeto inclui `gradle/wrapper/gradle-wrapper.properties`, mas **não inclui `gradle-wrapper.jar` ou scripts de wrapper**. Para criar o wrapper, com Gradle 8.9 instalado, execute `gradle wrapper --gradle-version 8.9` na raiz. Alternativamente, crie um novo projeto *Empty Views Activity* (Java, minSdk 26) no Android Studio e copie os arquivos `app/src/main` e as configurações de `app/build.gradle` deste projeto para o novo projeto gerado (que já tem wrapper).
4. Aguarde a sincronização de dependências Gradle pela internet.
5. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Instale o APK gerado em `app/build/outputs/apk/debug/app-debug.apk` no Android.

## Recursos

- 10 semanas, 4 etapas, treino de força terça, potência sexta.
- Carga **em kg por série**, editável no dia, sem cargas presumidas.
- Cálculo de sugestão em kg quando o usuário informa uma referência de 1RM.
- Check-in por exercício e conclusão por dia, histórico por data.
- Testes de CMJ/SJ/Sargent/sprint nas semanas 0, 5 e 10, gráfico de CMJ.
- Backup e importação de dados JSON; exportação de cargas em CSV.
- Armazenamento 100% local no aparelho por `localStorage` (WebView com DOM Storage habilitado).
- O Android Studio gera um APK cujo HTML é empacotado em `assets`, sem necessidade de servidor nem conexão de internet para treino.

## Cuidados

Os percentuais de 1RM são retirados do material, mas as adaptações na sexta-feira para preservar o futevôlei de sábado são decisões de programação de treino. Reduza a intensidade se houver fadiga excessiva, dor ou perda de técnica. A quinta de superiores é sugestão complementar, não retirada do PDF original.

## Arquivos principais

- `app/src/main/assets/index.html`: interface e lógica (HTML, CSS e JavaScript, sem bibliotecas externas).
- `app/src/main/java/br/com/impulsofutevolei/MainActivity.java`: WebView Android e salvamento/abertura de arquivo JSON/CSV.
- `app/src/main/AndroidManifest.xml`: declaração de app Android.
- `app/src/main/assets/manifest.webmanifest` e `service-worker.js`: instalação PWA em hospedagem HTTPS.


## Criar APK sem instalar Android Studio (GitHub Actions)

A pasta `.github/workflows/gerar-apk.yml` contém um fluxo de compilação automatizada no GitHub:

1. Crie um repositório GitHub e envie os arquivos da **pasta raiz do projeto** (incluindo a pasta oculta `.github`).
2. Abra a aba **Actions** > **Gerar APK Android** > **Run workflow**.
3. Ao fim, acesse a execução e baixe o artefato `Impulso-Futevolei-Android-APK`.
4. Extraia o ZIP do artefato e transfira o `app-debug.apk` para o Android.

O fluxo é fornecido como código-fonte e **não foi executado** neste ambiente. O APK é de depuração, adequado para instalação particular, não para publicar na Play Store.
